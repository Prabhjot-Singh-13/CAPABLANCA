from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')  # Render the main form page

@app.route('/play', methods=['POST'])
def play():
    player_name = request.form.get('player')  # Get selected player
    game_type = request.form.get('game')      # Get selected game type
    return render_template('play.html', player_name=player_name, game_type=game_type)

if __name__ == '__main__':
    app.run(debug=True)
